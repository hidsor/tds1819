package umu.tds.videos;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * Componente que permite cargar todos los v�deos desde un arhivo.
 * Esta carga se notificar� mediante un objeto VideosEvent, que contiene todos los videos cargados
 * 
 * @author Enrique Valero Leal
 * @author Vladyslav Grechyshkin
 *
 */
public class ComponenteBuscadorVideos implements IBuscadorVideos, Serializable {
	// ATRIBUTOS
	private static final long serialVersionUID = 1L;
	private String archivoVideos;		// Propiedad ligada
	private CargadorVideos cargadorVideos;
	private List<VideosListener> oyentesVideos;
	
	
	// CONSTRUCTOR
	public ComponenteBuscadorVideos() {
		archivoVideos = "";
		cargadorVideos = new CargadorVideos();
		this.oyentesVideos = new LinkedList<VideosListener>();	
	}
	
	
	
	// METODOS GET Y SET
	public String getArchivoVideos() {
		return archivoVideos;
	}

	/**
	 * Establece el archivo con los videos, notificando a los listeners de los videos
	 * cargados mediante un evento.
	 * @param archivoVideos
	 */
	public void setArchivoVideos(String archivoVideos) {
		// Cargamos los videos y notificamos mediante un VideosEvent
		this.archivoVideos = archivoVideos;
		notificarNuevosVideos(new VideosEvent(this, CargadorVideos.cargarVideos(archivoVideos)));
	}


	public CargadorVideos getCargadorVideos() {
		return cargadorVideos;
	}



	
	/**
	 * Dado el nombre de un archivo xml, carga los videos contenidos en este, notificando a
	 * todos los oyentes de este componente cuales han sido los videos cargados
	 * @param xml Archivo xml (ruta) con los vidos
	 */
	public void buscarVideo(String xml) {
		setArchivoVideos(xml);	
	}
	
	
	private void notificarNuevosVideos(VideosEvent evento) {
		List<VideosListener> copia;
		synchronized(oyentesVideos) {
			copia = new LinkedList<VideosListener>(oyentesVideos);
		}
		for (VideosListener listener : copia) {
			listener.nuevosVideos(evento);
		}
		
	}

	/**
	 * A�ade un oyente a la lista de oyentes del componente
	 * @param listener Oyente a a�adir
	 */
	public synchronized void addVideosListener(VideosListener listener) {
		oyentesVideos.add(listener);
	}
	
	/**
	 * Elimina un oyente de la lista de oyentes del componente
	 * @param listener Oyente a eliminar
	 */
	public synchronized void removeVideosListener(VideosListener listener) {
		oyentesVideos.remove(listener);
	}

}

package umu.tds.videos;


public interface IBuscadorVideos {
	public void buscarVideo(String xml);
}

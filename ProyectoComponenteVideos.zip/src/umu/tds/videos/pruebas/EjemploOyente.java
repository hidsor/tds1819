package umu.tds.videos.pruebas;

import umu.tds.videos.Etiqueta;
import umu.tds.videos.Video;
import umu.tds.videos.Videos;
import umu.tds.videos.VideosEvent;
import umu.tds.videos.VideosListener;

public class EjemploOyente implements VideosListener {

	@Override
	public void nuevosVideos(VideosEvent evento) {
		Videos videos = evento.getVideos();
		
		for (Video video : videos.getVideo()) {
			
			System.out.println("Video: " + video.getTitulo());
			System.out.println("    -> " + video.getUrl());
			
			for (Etiqueta etiqueta : video.getEtiqueta()) {
				System.out.println("    -> " + etiqueta.getNombre());				
			}
			
		}
	}

}

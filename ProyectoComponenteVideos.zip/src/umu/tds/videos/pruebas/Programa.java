/**
 * Este paquete solo se usa para mostrar el comportamiento del componente
 * definido en el paquete umu.tds.videos, por tanto no ser� incluido en el .jar
 */
package umu.tds.videos.pruebas;

import umu.tds.videos.ComponenteBuscadorVideos;

public class Programa {

	public static void main(String[] args) {

		ComponenteBuscadorVideos buscador = new ComponenteBuscadorVideos();
		EjemploOyente ejemplo = new EjemploOyente();
		buscador.addVideosListener(ejemplo);
		String cadena = "xml/videos.xml";
		buscador.buscarVideo(cadena);
		}
	
	}

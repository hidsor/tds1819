package umu.tds.videos;
import java.util.EventListener;
/**
 * 
 * Interfaz funcional que permite a una clase ser notificada medainte un evento del 
 * tipo VideosEvent, el cual contiene videos
 *
 * @author Enrique Valero Leal
 * @author Vladyslav Grechyshkin
 *
 */
public interface VideosListener extends EventListener {
	/**
	 * Notifica al objeto mediante un objeto VideosEvent
	 * @param evento Evento con el que se notifica a la clase
	 */
	public void nuevosVideos(VideosEvent evento);
}

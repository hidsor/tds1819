package umu.tds.videos;

import java.util.EventObject;
/**
 * Evento mediante el cual se notifican videos.
 * Usado por el componente buscador de videos para notificar a los listeners
 * de una nueva carga de videos.
 * 
 * @author Enrique Valero Leal
 * @author Vladyslav Grechyshkin
 *
 *
 */
public class VideosEvent extends EventObject {
	private static final long serialVersionUID = 1L;
	// ATRIBUTOS
	Videos videos;
	
	
	public VideosEvent(Object arg0, Videos videos) {
		super(arg0);
		this.videos = videos;
	}
	
	/**
	 * @return Los videos almacenados en el evento
	 */
	public Videos getVideos() {
		return videos;
	}
	
	

}
